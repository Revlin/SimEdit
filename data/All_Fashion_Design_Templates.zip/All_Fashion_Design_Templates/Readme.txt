Second Life Fashion Design Templates
January, 2003

==========================================
These are intended for use by Second Life content creators.  The  file
Using_the_SL_Fashion_Design_Templates.pdf contains instructions on how
to use these files.
==========================================

==========================================
See LICENSE.txt in this folder for the terms under which these files
are made available by Linden Research, Inc.
==========================================
